Name: Lake Summers
Class: ECE 3520 Section 001
Assignment: SDE 2

Pledge: On my honor I have neither given nor received aid on this exam.

File Descriptions:
- sde2.caml:
    Contains each of the helper functions, the required functions for
    the assignment, as well as commented out test cases below each one
    that were used to copy and paste the inputs into ocaml when testing.
- sde2.log:
    Contains the import of sde2.caml, the signatures of each function,
    as well as the inputs and outputs of 2 sample uses of each of the
    functions required. I have opted to use the first 2 examples from
    the project description for each function.
